package com.kawtar.examen1;

import java.util.ArrayList;

public class Groupe {
    private ArrayList<Evaluation> list;

    public Groupe  () {
        list = new ArrayList<>();
    }


    public void ajouter (Evaluation e){
        list.add(e);
    }

    public int totalEvaluation(){
        return list.size();
    }

    public int meilleurMatricule(){
        int matriculee =0;
        int meilleurS = -1;
        for(Evaluation evaluation : list){
            int s = evaluation.getNbreService();
            if(s>meilleurS)
            {
                meilleurS =s;
                matriculee=evaluation.getMatricule();
            }
        }
      return matriculee;
    }
}
