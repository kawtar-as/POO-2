package com.kawtar.examen1;

public class Evaluation {

    private int matricule, nbreService;

    public Evaluation(int matricule, int nbreService) {
        this.matricule = matricule;
        this.nbreService = nbreService;
    }

    public int getMatricule() {
        return matricule;
    }

    public int getNbreService() {
        return nbreService;
    }

}
