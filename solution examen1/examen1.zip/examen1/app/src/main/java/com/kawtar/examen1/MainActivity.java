package com.kawtar.examen1;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
        Ecouteur ec;
        Button btnservice, btnenregistrer ;
        EditText matricule ;
        TextView services,etudiants,meilleurE;

         Groupe g = new Groupe();
         int compteur = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ec = new Ecouteur();
        btnservice= findViewById(R.id.button);
        btnenregistrer= findViewById(R.id.button2);
        matricule = findViewById(R.id.editTextText3);
        services = findViewById(R.id.textView2);
        etudiants = findViewById(R.id.textView5);
        meilleurE = findViewById(R.id.textView7);

        btnservice.setOnClickListener(ec);
        btnenregistrer.setOnClickListener(ec);


    }
    private class Ecouteur implements View.OnClickListener {
        @Override
        public void onClick(View source) {
           if(source == btnservice){

               compteur+=1;
               services.setText(String.valueOf(compteur));
           }
           else {
               Evaluation e = new Evaluation(Integer.parseInt(String.valueOf(matricule.getText())),
                                                Integer.parseInt(String.valueOf(services.getText())));
               if(matricule.getText().length() > 7){
                   Toast toast = Toast.makeText(MainActivity.this,"plusgrand !",Toast.LENGTH_LONG);
                   toast.show();

               }
               g.ajouter(e);
                etudiants.setText(String.valueOf(g.totalEvaluation()));
                meilleurE.setText(String.valueOf(g.meilleurMatricule()));
               matricule.setText("");
               services.setText("");
               compteur = 0;
           }


        }
    }
}